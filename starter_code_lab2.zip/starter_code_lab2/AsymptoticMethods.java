import java.lang.Math;

class AsymptoticMethods {
    AsymptoticMethods() {
    }

    void Constant(int inputSize) {
    }

    void Logarithmic(int inputSize) {
    }

    void Linear(int inputSize) {
    }

    void LinearLog(int inputSize) {
    }

    void Quadratic(int inputSize) {
    }

    void Cubic(int inputSize) {
    }

    void Exponential(int inputSize) {
    }

    void Factorial(int inputSize) {
    }

    void Mystery(int inputSize) {
        if (inputSize <= 1) {
            return;
        }
        int logInputSize = (int) (Math.log(inputSize)/Math.log(2));
        Mystery(logInputSize);
    }
};
