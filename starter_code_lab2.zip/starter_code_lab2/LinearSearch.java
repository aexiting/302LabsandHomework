
class LinearSearch implements TimedAlgorithm {

    LinearSearch() {
    }

    public String GetName() {
        return "LinearSearch";
    }

    public void Run(int[] integerArray) {
        ConductLinearSearch(integerArray, 0);
    }

    public boolean ConductLinearSearch(int[] integerArray, int queryInteger) {
        for (int integerInArray : integerArray) {
            if (integerInArray == queryInteger)
                return true;
        }
        return false;
    }

    public int[] GetBestCaseInput(int arraySize) {
        int[] integerArray = new int[arraySize];
        // create best-case input
        return integerArray;
    }

    public int[] GetWorstCaseInput(int arraySize) {
        int[] integerArray = new int[arraySize];
        // create worst-case input
        return integerArray;
    }

    // not implemented
    public int[] GetAverageCaseInput(int arraySize) {
        int[] integerArray = new int[arraySize];
        // create average-case input
        return integerArray;
    }

};
